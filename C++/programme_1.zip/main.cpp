#include <iostream>
#include <conio.h>
using namespace std;
int main() {
    int num1 = 10, num2 = 20;
    char ch = 'a';
    cout <<"Number one: " <<num1 <<endl <<"Number two: "<<num2 <<endl <<"Character: " <<ch;
    
    

getch();    
}