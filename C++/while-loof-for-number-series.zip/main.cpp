#include <iostream>
#include <conio.h>

using namespace std;

int main (){
    
    int i = 1, num;
    
    cout <<"Enter a number: ";
    cin >> num;
    
    while (i<=num){
        
        cout << i <<endl;
        i++;
    }
    
    cout << "End of the loop";
    
    
    getch();
}