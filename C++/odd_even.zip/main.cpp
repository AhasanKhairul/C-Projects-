#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int a, b;
    cout <<"Enter a number: ";
    cin >>a;
    
    if (a%2 == 0){
    
    cout<<"The number is even ";
    }
    
    else 
    cout<< "The number is odd";
    
    
    
    
    getch();
}