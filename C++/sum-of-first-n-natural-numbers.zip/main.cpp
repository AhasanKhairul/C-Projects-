//problem: Find the sum of first n Natural Numbers

// C++ program to find the sum of first n natural numbers
// positive integers such as 1,2,3,...n are known as natural numbers





#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
/* In the above example, we have two variables num and sum. 
The sum variable is assigned with 0 and the num variable is 
assigned with the value provided by the user */    
    
    
    int num, sum = 0;
    
    
    cout << "Enter a number: ";
    cin >> num;
    
    for (int i = 1; i <= num; ++i) {
        sum += i;
        cout <<sum <<endl;
        
    }
    cout << "The sum of first " <<num <<" natural number is " <<sum;
        
    
    
    
    
    
    
    
    getch();
}