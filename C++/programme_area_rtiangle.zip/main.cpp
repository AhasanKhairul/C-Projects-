#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    double base, height, area;
    cout << "Enter the base: ";
    cin >> base;
    
    cout << "Enter the height: ";
    cin >> height;
    
    area = 0.5 * base * height;
    cout <<"The triangle area is: " <<area;
    
    
    
    
    
    
    getch();
}