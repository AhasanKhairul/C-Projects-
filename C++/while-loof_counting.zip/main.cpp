#include <iostream>
#include <conio.h>

using namespace std;

int main ()
{

  int num;

  cout << "Enter a number: ";
  cin >> num;

  int i = 1;

  while (i <= num)
    {

      cout << i << endl;
      i++;
    }



  getch;
}
