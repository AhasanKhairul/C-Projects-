#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int num;
    cout <<"Enter a number: ";
    cin >> num;
    if (num>0) {
        
        cout<<"Number is positive";
    }
    
    else if (num<0) {
        
        cout<<"Number is Negative";
    }
    
    else 
    
        cout <<"Numer Zero";
    
    
    getch();
}
