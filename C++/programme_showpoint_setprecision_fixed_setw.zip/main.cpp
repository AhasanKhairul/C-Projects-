#include <iostream>
#include <conio.h>
#include<iomanip> //for taking 12 digits after point
using namespace std;

int main() 
{
    
  float num1, num2, sum;
  
  cout<<showpoint;
  cout<<fixed;
  cout<<setprecision(2); //for taking 12 digits after point
  
  cout <<setw(10)<<"Enter two number: " <<endl; 
  cin >>num1 >>num2;
  cout <<setw(20)<<"First number is: " <<num1 <<endl;
  cout <<setw(20)<<"Second number is: " <<num2 <<endl;
  sum = num1 + num2;
  cout<<setw(20)<<"Total is: " <<sum <<endl; 
  
  
  float sub = num1 - num2;
  cout<<setw(20)<<"Subtraction is: " <<sub <<endl;
  
  
  
  float div = num1 / num2;
  cout<<setw(20)<<"Division is: " <<div <<endl;
  
  
  float mul = num1 * num2;
  cout<<setw(20)<<"Multiplication is: " <<mul <<endl;
  
  /*float mod = num1 % num2;
  cout<<"Remainder is: " <<mod;*/
  
  
  getch();
    
    
}
