#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int a;
    float f;
    double d;
    char ch;
    char name[20];
    
    int c = sizeof (name);
    cout << c;
    
    
    
    
    
    
    
    
    getch();
}