#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int year;
    cout <<"Enter the year: ";
    cin >>year;
    
    // if year is divisible by 4 AND not divisible by 100
    // OR if year is divisible by 400
    // then it is a leap year
    
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)){
        
        cout <<year <<" Is Leap Year ";
    }
    
    else {
        cout <<year <<" Is Not Leap Year";
    }
    
        getch();
    
}