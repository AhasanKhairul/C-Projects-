#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int i;
    
    for(i=1;i<=100;i++){
        
        cout <<"Bangladesh " <<i <<endl;
    }
    
    cout <<"end of 100";
    
    
    getch();
}