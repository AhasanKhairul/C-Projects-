#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int marks;
    cout <<"Enter the marks: ";
    cin >>marks;
    
    if (marks>=33){
    
    cout<<"PASS ";
    }
    
    else 
    cout<< "FAIL, Dont Give Up ";
    
    
    
    
    getch();
}