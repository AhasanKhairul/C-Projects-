#include <iostream>
#include <conio.h>

using namespace std;

int
main ()
{

  double num1, num2, num3, num4;

  cout << "Enter first number: ";
  cin >> num1;

  cout << "Enter second number: ";
  cin >> num2;

  cout << "Enter third number: ";
  cin >> num3;

  cout << "Enter fourth number: ";
  cin >> num4;

  if (num1 > num2 && num1 > num3 && num1 > num4)
    {

      cout << "First number is greater than all ";
    }

  else if (num2 > num1 && num2 > num3 && num2 > num4)
    {

      cout << "Second number is greater than all ";
    }

  else if (num3 > num1 && num3 > num2 && num3 > num4)
    {

      cout << "Third number is greater than all ";
    }

  else 
    {

      cout << "Fourth number is greater than all ";
    }
  getch ();
}
