#include <iostream>
#include <conio.h>
using namespace std;

int main() {
    
    double far, cel;
    cout<< "Enter your temperature in celsius: ";
    cin>> cel;
    
    far = (1.8 * cel) + 32;
    cout << "Temperature in Fahrenheit is: " <<far;
    
    
    
    
    
    getch();
    
}