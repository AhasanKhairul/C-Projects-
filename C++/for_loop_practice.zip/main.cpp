//https://www.programiz.com/cpp-programming/for-loop

#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int num, sum = 0;
    cout << "Enter a number: ";
    cin >> num;
    
    for(int i=1; i<=num; ++i){
        sum += i;
        cout <<sum <<endl;
    }
    
    cout <<sum <<endl;
    
    
    
    getch();
}
