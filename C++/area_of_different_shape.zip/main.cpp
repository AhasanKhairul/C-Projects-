#include <iostream>
#include<conio.h>
using namespace std;
int main(){
    
    double length, height;
    cout<<"input your length: " <<endl;
    cin>>length;
    cout<<"input your height: " <<endl;
    cin>>height;
    
    double area = 0.5 * length * height;
    cout <<"area is: " <<area;
    
    
    
    
    getch();
}