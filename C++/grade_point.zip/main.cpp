#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int marks;
    cout <<"Enter the number: ";
    cin >>marks;
    
    if (marks>100){
    
    cout<<"INVALID " ;
    }
    
    else if (marks<0){
    
    cout<<"INVALID " ;
    }
    else if (marks>=80){
    
    cout<<"Your letter grade is A+ " ;
    }
    
    else if (marks>=70){
    
    cout<<"Your letter grade is A " ;
    }
    
    else if (marks>=60){
    
    cout<<"Your letter grade is A- " ;
    }
    
    else if (marks>=50){
    
    cout<<"Your letter grade is B " ;
    }
    
    else if (marks>=40){
    
    cout<<"Your letter grade is C " ;
    }
    
    else if (marks>=33){
    
    cout<<"Your letter grade is D " ;
    }
    
    
    else {
    cout <<"Fail, Please try again ";
    
    }
    
    getch();
}