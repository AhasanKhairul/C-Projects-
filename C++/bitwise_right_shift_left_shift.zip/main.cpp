#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int a = 32, b = 12, c, d;
    
    c = a>>3;
    cout <<c <<endl;
    
    d = a<<3;
    cout <<d <<endl;
    
    
    
    
    
    getch();
}