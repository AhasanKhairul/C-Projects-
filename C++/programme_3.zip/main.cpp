#include <iostream>
#include <conio.h>
using namespace std;

int main() 
{
    
  float num1, num2, sum;
  cout<<showpoint;
  cout <<"Enter two number: " <<endl; 
  cin >>num1 >>num2;
  cout <<"First number is: " <<num1 <<endl;
  cout <<"Second number is: " <<num2 <<endl;
  sum = num1 + num2;
  cout<<"Total is: " <<sum <<endl; 
  
  cout<<showpoint;
  float sub = num1 - num2;
  cout<<"Subtraction is: " <<sub <<endl;
  
  cout<<showpoint;
  float div = num1 / num2;
  cout<<"Division is: " <<div <<endl;
  
  cout<<noshowpoint;
  float mul = num1 * num2;
  cout<<"Multiplication is: " <<mul <<endl;
  
  /*float mod = num1 % num2;
  cout<<"Remainder is: " <<mod;*/
  
  
  getch();
    
    
}
