#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int num;
    cout <<"Enter the number: ";
    cin >>num;
    
    if (num<0){
    
    cout<<"The absolute value is: " <<(-num) ;
    }
    
    else {
    cout <<"The absolute value is: " <<num;
    
    }
    
    getch();
}