//+ - ++ ..

#include <iostream>
#include <conio.h>
using namespace std;

int main() {
    
    int x = 6;
    int result = +x; 
    cout << result <<endl; 
    
    int y = 6;
    int result_1 = -y; 
    cout << result_1 <<endl;
    
    int z = 3;
    int p = --z;
    
    cout <<p <<endl;
    cout <<z;
    
    
    
    
    getch();
}