#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int a, b, sum;
    
    sum = (a = 10, b = 20, sum = a+b);
    cout << sum;
    
    
    
    
    
    
    
    getch();
}