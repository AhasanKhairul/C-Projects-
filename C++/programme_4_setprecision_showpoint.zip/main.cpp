#include <iostream>
#include <conio.h>
#include<iomanip> //for taking 12 digits after point
using namespace std;

int main() 
{
    
  float num1, num2, sum;
  cout<<showpoint;
  cout<<setprecision(12); //for taking 12 digits after point
  cout <<"Enter two number: " <<endl; 
  cin >>num1 >>num2;
  cout <<"First number is: " <<num1 <<endl;
  cout <<"Second number is: " <<num2 <<endl;
  sum = num1 + num2;
  cout<<"Total is: " <<sum <<endl; 
  
  cout<<showpoint;
  float sub = num1 - num2;
  cout<<"Subtraction is: " <<sub <<endl;
  
  cout<<showpoint;
  cout<<setprecision(12);
  float div = num1 / num2;
  cout<<"Division is: " <<div <<endl;
  
  cout<<showpoint;
  float mul = num1 * num2;
  cout<<"Multiplication is: " <<mul <<endl;
  
  /*float mod = num1 % num2;
  cout<<"Remainder is: " <<mod;*/
  
  
  getch();
    
    
}
