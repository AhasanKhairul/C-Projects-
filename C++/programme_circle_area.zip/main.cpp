#include <iostream>
#include<math.h>
#include<conio.h>

using namespace std;
int main(){
    
    
    double radius;
    cout<<"input your radius: " <<endl;
    cin>>radius;
    
    double area = M_PI * radius * radius;
    cout <<"area is: " <<area;
    
    
    
    
    getch();
}