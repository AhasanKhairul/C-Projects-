#include <iostream>
#include <conio.h>
#include<iomanip>
using namespace std;

int main() {
    
    double far, cel;
    cout<<showpoint;
    cout<<fixed;
    cout<<setprecision(2);
    cout<<setw(50)<< "Enter your temperature in Farhenheit: ";
    cin>> far;
    
    
    cel = (far - 32) / 1.8;
    
    
    cout <<setw(50) <<"Temperature in Celsius is: " <<cel;
    
    
    
    
    
    getch();
    
}