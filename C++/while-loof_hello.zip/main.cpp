#include <iostream>
#include <conio.h>

using namespace std;

int main(){
    
    int i = 1, n;
    
    cout <<"Enter a number ";
    cin >> n;
    
        while (i<=n) {
        
        cout <<"Hello " <<i  <<endl;
        i++;
    }
    
    
    
    
    
    
    
    
    
    getch();
}