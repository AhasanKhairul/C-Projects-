#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int a, b;
    cout <<"Enter first number: ";
    cin >>a;
    
    cout <<"Enter second number: ";
    cin >>b;
    if (a>b){
    
    cout<<"First number is larger second ";
    }
    
    else 
    cout<< "First number is smaller than second ";
    
    
    
    
    getch();
}