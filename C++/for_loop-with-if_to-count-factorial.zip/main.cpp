#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int num;
    long factorial = 1;
    
    cout <<"Enter a number: ";
    cin >> num;
    
    if (num>0){
    
    
    for(int i=1; i<=num; ++i) {
        factorial *= i;
        
        
    }
    
    cout <<factorial;
    }
    
    else {
        
        
        cout << "number is not in the range! ";
    }
    
    
    
    
    
    
    getch();
}