#include <iostream>
#include <conio.h>

using namespace std;

int main() {
    
    int num;
    cout << "Enter a number:";
    cin >> num;
    
    (num>=0) ? cout<<num <<" is positive" : cout<<num <<" is negative"; 
    
    
    
    
    
    
    
    
    
    
    
    getch();
    
    
}