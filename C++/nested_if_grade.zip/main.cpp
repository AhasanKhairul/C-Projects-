#include <iostream>
#include <conio.h>

using namespace std;

int main(){
    
    int num;
    cout <<"Enter your number: ";
    cin >> num;
    
    if (num>32){
    
    if (num>=80){
        cout<< " Your grade is A+";
        
    }
    
    if (num>=70){
        cout<< " Your grade is A";
        
    }    
    
    if (num>=60){
        cout<< " Your grade is A-";
        
    }
    
    if (num>=50){
        cout<< " Your grade is B";
        
    }    
    
    if (num>=40){
        cout<< " Your grade is C";
        
    }    
    
    if (num>=33){
        cout<< " Your grade is D";
        
    }     
       
    }
    
       
    else {
        
        cout << "Fail, Please try again!";
    }
    
    
    getch();
}